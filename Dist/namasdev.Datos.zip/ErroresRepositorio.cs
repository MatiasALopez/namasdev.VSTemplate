﻿using System;

using namasdev.Data;
using namasdev.Data.Entity;

using MyApp.Entidades;
using $safeprojectname$.Sql;

namespace $safeprojectname$
{
    public interface IErroresRepositorio : IRepositorio<Error, Guid>
    {
    }

    public class ErroresRepositorio : Repositorio<SqlContext, Error, Guid>, IErroresRepositorio
    {
    }
}
