﻿
namespace $safeprojectname$.Views
{
    public class Account
    {
        public const string ACTIVAR_CUENTA_CONFIRMACION = "ActivarCuentaConfirmacion";
        public const string OLVIDO_PASSWORD_CONFIRMACION = "OlvidoPasswordConfirmacion";
        public const string RESETEAR_PASSWORD_CONFIRMACION = "ResetearPasswordConfirmacion";
    }
}