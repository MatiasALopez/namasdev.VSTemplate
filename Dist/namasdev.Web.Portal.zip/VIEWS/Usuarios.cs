﻿
namespace $safeprojectname$.Views
{
    public class Usuarios
    {
        public const string USUARIO = "Usuario";
    }
}