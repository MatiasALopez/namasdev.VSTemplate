﻿
namespace $safeprojectname$.Views
{
    public class Shared
    {
        public const string ACCESO_DENEGADO = "AccesoDenegado";
        public const string ERROR = "Error";
    }
}