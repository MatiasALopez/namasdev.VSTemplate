﻿using System.Collections.Generic;

namespace $safeprojectname$.Models
{
    public class BootstrapSelectResultData
    {
        public string text { get; set; }
        public string value { get; set; }
        public Dictionary<string,string> data { get; set; }
    }
}