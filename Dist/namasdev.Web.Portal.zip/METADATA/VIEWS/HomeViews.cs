namespace $safeprojectname$.Metadata.Views
{
    public class HomeViews
    {
        public const string INDEX = "Index";
    }
}
