namespace $safeprojectname$.Metadata.Views
{
    public class UsuariosViews
    {
        public const string INDEX = "Index";
        public const string USUARIO = "Usuario";
    }
}
