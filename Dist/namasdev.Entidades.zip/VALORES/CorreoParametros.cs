﻿
namespace $safeprojectname$
{
    public class CorreosParametros
    {
        public const short ACTIVAR_USUARIO = 1;
        public const short RESETEAR_PASSWORD = 2;
    }
}
