﻿
namespace $safeprojectname$
{
    public class AzureBlobContainer
    {
        //public const string RECURSOS = "recursos";
    }
    
    public class AzureBlobDirectory
    {
        //public class Recursos
        //{
        //    public const string EXCEL = "excel";
        //}
    }

    public class AzureBlob
    {
        //public class Recursos
        //{
        //    public class Excel
        //    {
                
        //    }
        //}
    }
}
