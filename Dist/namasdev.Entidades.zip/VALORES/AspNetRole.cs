﻿namespace $safeprojectname$.Valores
{
    public class AspNetRoles
    {
        public const string ADMINISTRADOR = "Administrador";
    }
}
