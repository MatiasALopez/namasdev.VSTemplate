﻿namespace $safeprojectname$
{
    public class AspNetRoles
    {
        public const string ADMINISTRADOR = "Administrador";
    }
}
