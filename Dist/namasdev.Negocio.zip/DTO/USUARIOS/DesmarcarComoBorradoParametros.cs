﻿namespace $safeprojectname$.DTO.Usuarios
{
    public class DesmarcarComoBorradoParametros : ParametrosEntidadBase<string>
    {
    }
}
