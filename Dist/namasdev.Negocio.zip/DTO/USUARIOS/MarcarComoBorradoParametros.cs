﻿namespace $safeprojectname$.DTO.Usuarios
{
    public class MarcarComoBorradoParametros : ParametrosEntidadBase<string>
    {
    }
}
