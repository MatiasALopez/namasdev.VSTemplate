﻿namespace $safeprojectname$.DTO
{
    public class ParametrosConUsuarioBase
    {
        public string UsuarioLogueadoId { get; set; }
    }
}
